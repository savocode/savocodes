<?php

namespace App\Exceptions;

class RideSeatsExhausted extends BaseException {}
