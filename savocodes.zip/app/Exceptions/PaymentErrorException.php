<?php

namespace App\Exceptions;

class PaymentErrorException extends BaseException {}
