<?php

namespace App\Exceptions;

class InvalidUserTypeException extends BaseException {}
