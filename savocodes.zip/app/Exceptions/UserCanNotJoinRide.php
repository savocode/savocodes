<?php

namespace App\Exceptions;

class UserCanNotJoinRide extends BaseException {}
