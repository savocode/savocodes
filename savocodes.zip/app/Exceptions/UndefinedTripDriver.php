<?php

namespace App\Exceptions;

class UndefinedTripDriver extends BaseException {}
