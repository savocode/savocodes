<?php

namespace App\Exceptions;

class InvalidRouteGiven extends BaseException {}
