# LifeCare - AppMaister Project

## Installation

To install this package you will need
  - Laravel 5.4
  - PHP >= 5.6.6

The best way to install this package is with the help of composer. Clone this repo and run
```
composer update
```

It'll download all dependencies to project, then import database file and configure project `.env` file

### Team
-- Ahsaan Muhammad Yousuf (Backend)

-- Hassan Ahmed (Cross Platform Xamarin Developer)

-- Mohsin Lakhani (Project Manager)
 
### Backend Team
-- Ahsaan Muhammad Yousuf

-- Adnan Tariq
